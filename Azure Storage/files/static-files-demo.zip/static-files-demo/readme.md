[Azure Storage Explorer](https://azure.microsoft.com/en-us/features/storage-explorer/)

---

Edit following: 
* index.html > line 20: `<h1 id="text01">&lt;your name&gt;</h1>`
* /assets/main.js > line 1443: `timestamp` (Use [epoch time converter](https://www.epochconverter.com/)) 